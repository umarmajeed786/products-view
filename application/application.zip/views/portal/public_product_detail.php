 <img src="<?= base_url('uploads/images/') . $product->cover_image ?>" class="img-responsive">
<div class="row" >
    <?php
    echo "<pre>";
    if ($product) {
        print_r($product);
    }
    ?>
</div>
